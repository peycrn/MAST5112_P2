package za.ac.iie.mast_poep2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EditItemsScreenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_items_screen)

        val itemNameEditText: EditText = findViewById(R.id.itemNameEditText)
        val itemDescriptionEditText: EditText = findViewById(R.id.itemDescriptionEditText)
        val itemPriceEditText: EditText = findViewById(R.id.itemPriceEditText)
        val saveButton: Button = findViewById(R.id.saveButton)
        val removeButton: Button = findViewById(R.id.removeButton)
        val backButton: Button = findViewById(R.id.backButton)

        // Saving the menu item
        saveButton.setOnClickListener {
            val itemName = itemNameEditText.text.toString()
            val itemDescription = itemDescriptionEditText.text.toString()
            val itemPrice = itemPriceEditText.text.toString().toDoubleOrNull()

            if (itemName.isNotBlank() && itemDescription.isNotBlank() && itemPrice != null) {
                // Save item (e.g., add it to a menu array or database)
                Toast.makeText(this, "$itemName added", Toast.LENGTH_SHORT).show()
                finish() // Go back to the home screen after saving
            } else {
                Toast.makeText(this, "Please fill in all fields correctly", Toast.LENGTH_SHORT).show()
            }
        }

        // Removing a menu item
        removeButton.setOnClickListener {
            // Implement the logic to remove the item
            Toast.makeText(this, "Item removed", Toast.LENGTH_SHORT).show()
        }

        // Going back to the previous screen
        backButton.setOnClickListener {
            finish()
        }
    }
}
