package za.ac.iie.mast_poep2

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

// Data class for menu items
data class MenuItem(
    val name: String,
    val price: Double,
    val description: String
)

class HomescreenActivity : AppCompatActivity() {

    // Define menu items with descriptions
    private val starters = listOf(
        MenuItem("Sushi", 50.00, "Delicious sushi rolls with fresh fish."),
        MenuItem("Prawn Soup", 45.00, "A rich and flavorful prawn soup.")
    )

    private val mainCourses = listOf(
        MenuItem("Beef Chow Mein", 120.00, "Stir-fried beef with noodles and vegetables."),
        MenuItem("Chicken Chop Suey", 110.00, "Chicken with a mix of vegetables in a savory sauce.")
    )

    private val desserts = listOf(
        MenuItem("Peppermint Tart", 60.00, "A sweet tart with a refreshing peppermint flavor."),
        MenuItem("Chocolate Mousse Cake", 70.00, "A rich chocolate mousse layered cake.")
    )

    private lateinit var selectedItemsTextView: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homescreen)

        selectedItemsTextView = findViewById(R.id.selectedItemsTextView)

        // Setting up buttons for course selection
        val viewStartersButton: Button = findViewById(R.id.viewStartersButton)
        val viewMainCoursesButton: Button = findViewById(R.id.viewMainCoursesButton)
        val viewDessertsButton: Button = findViewById(R.id.viewDessertsButton)
        val doneButton: Button = findViewById(R.id.doneButton)

        viewStartersButton.setOnClickListener {
            showMenuDialog(starters, "Select a Starter")
        }

        viewMainCoursesButton.setOnClickListener {
            showMenuDialog(mainCourses, "Select a Main Course")
        }

        viewDessertsButton.setOnClickListener {
            showMenuDialog(desserts, "Select a Dessert")
        }

        // "Done" button action
        doneButton.setOnClickListener {
            showSummaryDialog()
        }

        // Existing navigation buttons (edit items, filter items, back)
        val editItemsButton: Button = findViewById(R.id.editItemsButton)
        val filterItemsButton: Button = findViewById(R.id.filterItemsButton)
        val backButton: Button = findViewById(R.id.backButton)

        // Navigate to Edit Items Screen
        editItemsButton.setOnClickListener {
            val intent = Intent(this, EditItemsScreenActivity::class.java)
            startActivity(intent)
        }

        // Navigate to Filter Screen
        filterItemsButton.setOnClickListener {
            val intent = Intent(this, FilterScreenActivity::class.java)
            startActivity(intent)
        }

        // Navigate back to Welcome Screen
        backButton.setOnClickListener {
            finish() // Assuming going back to previous screen
        }
    }

    // Function to show the menu dialog
    private fun showMenuDialog(menuItems: List<MenuItem>, title: String) {
        val itemNames = menuItems.map { it.name }.toTypedArray()

        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)
        builder.setItems(itemNames) { _, which ->
            // Display the selected item details
            val selectedItem = menuItems[which]
            showItemDetails(selectedItem)
            updateSelectedItems(selectedItem)
        }
        builder.show()
    }

    // Function to show the details of the selected item
    private fun showItemDetails(item: MenuItem) {
        val descriptionDialog = AlertDialog.Builder(this)
            .setTitle(item.name)
            .setMessage("Price: R${item.price}\nDescription: ${item.description}")
            .setPositiveButton("OK", null)
            .create()
        descriptionDialog.show()
    }

    // Function to update the selected items text view
    private fun updateSelectedItems(item: MenuItem) {
        val currentText = selectedItemsTextView.text.toString()
        val updatedText = if (currentText.isEmpty()) {
            "Selected Items:\n${item.name} - R${item.price}"
        } else {
            "$currentText\n${item.name} - R${item.price}"
        }
        selectedItemsTextView.text = updatedText
    }

    // Function to show summary dialog on "Done" button click
    private fun showSummaryDialog() {
        val summaryDialog = AlertDialog.Builder(this)
            .setTitle("Summary of Selected Items")
            .setMessage(selectedItemsTextView.text)
            .setPositiveButton("OK", null)
            .create()
        summaryDialog.show()
    }
}
