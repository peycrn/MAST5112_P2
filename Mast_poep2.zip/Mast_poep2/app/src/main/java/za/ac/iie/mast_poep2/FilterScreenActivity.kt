package za.ac.iie.mast_poep2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class FilterScreenActivity : AppCompatActivity() {

    private val starters = listOf("Sushi", "Prawn Soup")
    private val mainCourses = listOf("Beef Chow Mein", "Chicken Chow Mein", "Prawn Chow Mein", "Chicken Chop Suey")
    private val desserts = listOf("Peppermint Tart", "Chocolate Mousse Cake")

    private val allMenuItems by lazy {
        starters + mainCourses + desserts
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter_screen)

        // Initialize UI components
        val filterEditText: EditText = findViewById(R.id.filterEditText)
        val searchButton: Button = findViewById(R.id.searchButton)
        val clearButton: Button = findViewById(R.id.clearButton)
        val backButton: Button = findViewById(R.id.backButton)
        val filteredItemsTextView: TextView = findViewById(R.id.filteredItemsTextView)

        // Set up search button click listener
        searchButton.setOnClickListener {
            val query = filterEditText.text.toString().lowercase()
            filterMenuItems(query, filteredItemsTextView)
        }

        // Set up clear button click listener
        clearButton.setOnClickListener {
            clearFilter(filterEditText, filteredItemsTextView)
        }

        // Set up back button click listener
        backButton.setOnClickListener {
            finish() // Navigate back to the previous screen
        }
    }

    // Function to filter menu items based on the query
    private fun filterMenuItems(query: String, filteredItemsTextView: TextView) {
        val filteredItems = allMenuItems.filter { it.lowercase().contains(query) }
        filteredItemsTextView.text = if (filteredItems.isNotEmpty()) {
            filteredItems.joinToString(separator = "\n")
        } else {
            "No items found"
        }
    }

    // Function to clear the filter and reset the UI
    private fun clearFilter(filterEditText: EditText, filteredItemsTextView: TextView) {
        filterEditText.text.clear()
        filteredItemsTextView.text = ""
    }
}
